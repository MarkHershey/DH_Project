var user_details =  {
  "screen_name" : "POTUS",
  "location" : "Washington, D.C.",
  "full_name" : "President Obama",
  "bio" : "Dad, husband, and 44th President of the United States. Tweets may be archived: http:\/\/t.co\/eVVzoATsAR.",
  "id" : "1536791610",
  "created_at" : "2013-06-21 16:02:21 +0000"
}
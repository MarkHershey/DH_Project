Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680464195993911296",
  "text" : "From the Obama family to yours, Merry Christmas! And a special thank you to all our men and women in uniform this holiday season.",
  "id" : 680464195993911296,
  "created_at" : "2015-12-25 19:04:41 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 17, 21 ],
      "id_str" : "19923144",
      "id" : 19923144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679773729749078016",
  "text" : "I'm proud of the @NBA for taking a stand against gun violence. Sympathy for victims isn't enough \u2013 change requires all of us speaking up.",
  "id" : 679773729749078016,
  "created_at" : "2015-12-23 21:21:01 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/hn98uGsjKZ",
      "expanded_url" : "http:\/\/wpo.st\/05Vy0",
      "display_url" : "wpo.st\/05Vy0"
    } ]
  },
  "geo" : { },
  "id_str" : "678656661024858112",
  "text" : "Zaevion Dobson died saving three friends from getting shot. He was a hero at 15. What's our excuse for not acting? https:\/\/t.co\/hn98uGsjKZ",
  "id" : 678656661024858112,
  "created_at" : "2015-12-20 19:22:11 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Hubble",
      "screen_name" : "NASA_Hubble",
      "indices" : [ 11, 23 ],
      "id_str" : "14091091",
      "id" : 14091091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StarWars",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vVBSVTpH2L",
      "expanded_url" : "http:\/\/go.nasa.gov\/1PbjXic",
      "display_url" : "go.nasa.gov\/1PbjXic"
    } ]
  },
  "geo" : { },
  "id_str" : "677991253259264000",
  "text" : "RT @NASA: .@NASA_Hubble found what looks like a cosmic lightsaber in our Milky Way galaxy: https:\/\/t.co\/vVBSVTpH2L #StarWars https:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hubble",
        "screen_name" : "NASA_Hubble",
        "indices" : [ 1, 13 ],
        "id_str" : "14091091",
        "id" : 14091091
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/677566544164073472\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/PJId3ThYRA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWczLo9WUAAwErw.jpg",
        "id_str" : "677566544008859648",
        "id" : 677566544008859648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWczLo9WUAAwErw.jpg",
        "sizes" : [ {
          "h" : 712,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 863
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 863
        } ],
        "display_url" : "pic.twitter.com\/PJId3ThYRA"
      } ],
      "hashtags" : [ {
        "text" : "StarWars",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/vVBSVTpH2L",
        "expanded_url" : "http:\/\/go.nasa.gov\/1PbjXic",
        "display_url" : "go.nasa.gov\/1PbjXic"
      } ]
    },
    "geo" : { },
    "id_str" : "677566544164073472",
    "text" : ".@NASA_Hubble found what looks like a cosmic lightsaber in our Milky Way galaxy: https:\/\/t.co\/vVBSVTpH2L #StarWars https:\/\/t.co\/PJId3ThYRA",
    "id" : 677566544164073472,
    "created_at" : "2015-12-17 19:10:27 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 677991253259264000,
  "created_at" : "2015-12-18 23:18:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/677222716303364098\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Kud56ChsBO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWX6eMYU4AEljDq.jpg",
      "id_str" : "677222715615404033",
      "id" : 677222715615404033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWX6eMYU4AEljDq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Kud56ChsBO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677222716303364098",
  "text" : "Congrats on a great career, Abby Wambach. For the goals you\u2019ve scored &amp; the kids you\u2019ve inspired, you\u2019re the GOAT! https:\/\/t.co\/Kud56ChsBO",
  "id" : 677222716303364098,
  "created_at" : "2015-12-16 20:24:12 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675812094902714369",
  "text" : "The strong Paris agreement on climate means a safer, more secure world for our kids. A perfect example of what American leadership can do.",
  "id" : 675812094902714369,
  "created_at" : "2015-12-12 22:58:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/675062773307588610\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/RJfKkield9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV5OAA9WoAMQk4O.jpg",
      "id_str" : "675062756316454915",
      "id" : 675062756316454915,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV5OAA9WoAMQk4O.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RJfKkield9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675062773307588610",
  "text" : "The opioid epidemic is destroying lives. We need to put treatment within reach of anyone who needs it. https:\/\/t.co\/RJfKkield9",
  "id" : 675062773307588610,
  "created_at" : "2015-12-10 21:21:21 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674735966830116864",
  "text" : "Herzlichen Gl\u00FCckwunsch to my friend and Time's Person of the Year, Angela Merkel! Thanks for your moral leadership and strong partnership.",
  "id" : 674735966830116864,
  "created_at" : "2015-12-09 23:42:45 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674620408642084865",
  "text" : "150 years since the abolition of slavery, a turning point in our history. Progress - that's our story.",
  "id" : 674620408642084865,
  "created_at" : "2015-12-09 16:03:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]
Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/r8TGIJICh7",
      "expanded_url" : "http:\/\/lat.ms\/1TphKB4",
      "display_url" : "lat.ms\/1TphKB4"
    } ]
  },
  "geo" : { },
  "id_str" : "693841529169952768",
  "text" : "Cedrick; way to go on your perfect score! How about you come by the next White House Science Fair? https:\/\/t.co\/r8TGIJICh7",
  "id" : 693841529169952768,
  "created_at" : "2016-01-31 17:01:26 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/A3qPizu4p2",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "693818704019193860",
  "text" : "If you or someone you care about needs affordable health coverage, head over to https:\/\/t.co\/A3qPizu4p2. Today's the last day to sign up!",
  "id" : 693818704019193860,
  "created_at" : "2016-01-31 15:30:44 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/OJAsaK6ImG",
      "expanded_url" : "http:\/\/nyti.ms\/23x9PWO",
      "display_url" : "nyti.ms\/23x9PWO"
    } ]
  },
  "geo" : { },
  "id_str" : "693116531064967168",
  "text" : "We just took an important step on equal pay. Let's keep at it until every woman &amp; girl gets a fair shot at success: https:\/\/t.co\/OJAsaK6ImG",
  "id" : 693116531064967168,
  "created_at" : "2016-01-29 17:00:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/691735740649050112\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/497Wkkve58",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZmJ_MIUsAA5GKP.jpg",
      "id_str" : "691735736458981376",
      "id" : 691735736458981376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZmJ_MIUsAA5GKP.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/497Wkkve58"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691735740649050112",
  "text" : "The science couldn't be clearer - we owe it to our kids to do everything we can to combat climate change. https:\/\/t.co\/497Wkkve58",
  "id" : 691735740649050112,
  "created_at" : "2016-01-25 21:33:47 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689842173999640576",
  "geo" : { },
  "id_str" : "689843464951885824",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Seven years ago I bet on American workers and the American auto industry. I\u2019d make that bet again any day of the week.",
  "id" : 689843464951885824,
  "in_reply_to_status_id" : 689842173999640576,
  "created_at" : "2016-01-20 16:14:33 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689841261902098432",
  "geo" : { },
  "id_str" : "689842173999640576",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Cars and trucks made in the USA are more fuel efficient than ever before \u2013 and still the best in the world.",
  "id" : 689842173999640576,
  "in_reply_to_status_id" : 689841261902098432,
  "created_at" : "2016-01-20 16:09:25 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/689841261902098432\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/kLruJgpZI1",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CZLO5D_UMAA4ioF.png",
      "id_str" : "689841172659843072",
      "id" : 689841172659843072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CZLO5D_UMAA4ioF.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kLruJgpZI1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689840513852137477",
  "geo" : { },
  "id_str" : "689841261902098432",
  "in_reply_to_user_id" : 1536791610,
  "text" : "American automakers have added more than 640,000 jobs since mid-2009 \u2013 the strongest job growth on record. https:\/\/t.co\/kLruJgpZI1",
  "id" : 689841261902098432,
  "in_reply_to_status_id" : 689840513852137477,
  "created_at" : "2016-01-20 16:05:48 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/689840513852137477\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/pDc8W8mtb5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZLOSq7UAAIB2Cn.jpg",
      "id_str" : "689840513097138178",
      "id" : 689840513097138178,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZLOSq7UAAIB2Cn.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pDc8W8mtb5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689840000456794112",
  "geo" : { },
  "id_str" : "689840513852137477",
  "in_reply_to_user_id" : 1536791610,
  "text" : "In 2009, auto sales hit a 27-year low. Last year, they hit an all-time high. https:\/\/t.co\/pDc8W8mtb5",
  "id" : 689840513852137477,
  "in_reply_to_status_id" : 689840000456794112,
  "created_at" : "2016-01-20 16:02:49 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689840000456794112",
  "text" : "Headed to the Detroit Auto Show today to showcase how our auto industry has come roaring back from the financial crisis. Here are the stats:",
  "id" : 689840000456794112,
  "created_at" : "2016-01-20 16:00:47 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689100817580867584",
  "text" : "Today we honor a man who challenged us to bend the arc of the moral universe toward justice. Let's keep working to realize Dr. King's dream.",
  "id" : 689100817580867584,
  "created_at" : "2016-01-18 15:03:32 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687699148468977665",
  "text" : "Alright everyone, this was a lot of fun. Thanks for the great conversation. i'll be back soon!",
  "id" : 687699148468977665,
  "created_at" : "2016-01-14 18:13:48 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 18, 32 ],
      "id_str" : "44177383",
      "id" : 44177383
    }, {
      "name" : "Everytown",
      "screen_name" : "Everytown",
      "indices" : [ 63, 73 ],
      "id_str" : "250386727",
      "id" : 250386727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/ATm1M4iMgU",
      "expanded_url" : "http:\/\/americansforresponsiblesolutions.org",
      "display_url" : "americansforresponsiblesolutions.org"
    } ]
  },
  "in_reply_to_status_id_str" : "687698446619312128",
  "geo" : { },
  "id_str" : "687698858948726784",
  "in_reply_to_user_id" : 1536791610,
  "text" : "places to start - @GabbyGiffords's https:\/\/t.co\/ATm1M4iMgU and @Everytown",
  "id" : 687698858948726784,
  "in_reply_to_status_id" : 687698446619312128,
  "created_at" : "2016-01-14 18:12:39 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/dZ0vRltrZg",
      "expanded_url" : "https:\/\/twitter.com\/drpearcekorb\/status\/687429380755308544",
      "display_url" : "twitter.com\/drpearcekorb\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687698446619312128",
  "text" : "great - we need well-meaning folks from all stripes to get info on how we can respect 2A and reduce gun violence https:\/\/t.co\/dZ0vRltrZg",
  "id" : 687698446619312128,
  "created_at" : "2016-01-14 18:11:01 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/eUr3rZ3UN7",
      "expanded_url" : "https:\/\/twitter.com\/nialler4th_lee\/status\/687669713313349633",
      "display_url" : "twitter.com\/nialler4th_lee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687697711605272576",
  "text" : "the night aca passed; standing on truman balcony with all staff whod made it happen, knowing we'd helped millions. https:\/\/t.co\/eUr3rZ3UN7",
  "id" : 687697711605272576,
  "created_at" : "2016-01-14 18:08:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fuTdewJcyh",
      "expanded_url" : "https:\/\/twitter.com\/balau\/status\/687670118847885312",
      "display_url" : "twitter.com\/balau\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687697228895399937",
  "text" : "despite court cases like citizens united ill work with orgs\/states across US to find new ways 2 reduce $ in politics https:\/\/t.co\/fuTdewJcyh",
  "id" : 687697228895399937,
  "created_at" : "2016-01-14 18:06:10 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687695621810032640",
  "geo" : { },
  "id_str" : "687695962198781953",
  "in_reply_to_user_id" : 1536791610,
  "text" : "so we all need to speak out against bias and stereotypes, to protect the freedom of others, and our own as well.",
  "id" : 687695962198781953,
  "in_reply_to_status_id" : 687695621810032640,
  "created_at" : "2016-01-14 18:01:08 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AM1JLoA1TI",
      "expanded_url" : "https:\/\/twitter.com\/marcplummer1998\/status\/687655494098407425",
      "display_url" : "twitter.com\/marcplummer199\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687695621810032640",
  "text" : "overwhelming majority of americans understand of diversity and religious pluralism is one of our greatest strengths  https:\/\/t.co\/AM1JLoA1TI",
  "id" : 687695621810032640,
  "created_at" : "2016-01-14 17:59:47 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ElBcrjxa6L",
      "expanded_url" : "https:\/\/twitter.com\/shirleyp_2009\/status\/687660738752544768",
      "display_url" : "twitter.com\/shirleyp_2009\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687695122327158785",
  "text" : "health care inflation lowest in decades since ACA passed; problem is more costs passed to workers thru copays, etc. https:\/\/t.co\/ElBcrjxa6L",
  "id" : 687695122327158785,
  "created_at" : "2016-01-14 17:57:48 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Du1gflVYp4",
      "expanded_url" : "https:\/\/twitter.com\/kool_ant\/status\/687671251112861696",
      "display_url" : "twitter.com\/kool_ant\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687694645090844672",
  "text" : "love em all, but as a bulls fan got to go with mj. in baton rouge, just met lsu freshman ben simmons - will be great https:\/\/t.co\/Du1gflVYp4",
  "id" : 687694645090844672,
  "created_at" : "2016-01-14 17:55:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/gQg3FEHXxo",
      "expanded_url" : "https:\/\/twitter.com\/Brentrou\/status\/687663122832846852",
      "display_url" : "twitter.com\/Brentrou\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687694262226432000",
  "text" : "new power plant rule reduces biggest source of CO2; now we need to invest in clean energy tech, energy efficiency. https:\/\/t.co\/gQg3FEHXxo",
  "id" : 687694262226432000,
  "created_at" : "2016-01-14 17:54:23 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/08mDX2H4Pt",
      "expanded_url" : "https:\/\/twitter.com\/1time4bryant\/status\/687674876069453824",
      "display_url" : "twitter.com\/1time4bryant\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687693536204996608",
  "text" : "new LA gov edwards just expanded medicaid; gets 1000s coverage &amp; helps the state budget. more states need to follow  https:\/\/t.co\/08mDX2H4Pt",
  "id" : 687693536204996608,
  "created_at" : "2016-01-14 17:51:30 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/RS9XFDpp9c",
      "expanded_url" : "https:\/\/twitter.com\/SydAlexisss\/status\/687662507348127744",
      "display_url" : "twitter.com\/SydAlexisss\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687692698573082624",
  "text" : "Expanded pell grants, capped loan repayments at 10% income, but now want to also make 2 yrs community college free. https:\/\/t.co\/RS9XFDpp9c",
  "id" : 687692698573082624,
  "created_at" : "2016-01-14 17:48:10 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/687692019372707840\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qjVcwg8tIi",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CYssNp4U0AAHAnN.png",
      "id_str" : "687691981196152832",
      "id" : 687691981196152832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CYssNp4U0AAHAnN.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qjVcwg8tIi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687692019372707840",
  "text" : "Before I start, wanted to share this. Liberia is now Ebola-free. Great example of what we can achieve when we lead. https:\/\/t.co\/qjVcwg8tIi",
  "id" : 687692019372707840,
  "created_at" : "2016-01-14 17:45:28 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/687691919065915392\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/jA1MEbwcxg",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/687691515167019008\/pu\/img\/lNWrxqngAzseuY13.jpg",
      "id_str" : "687691515167019008",
      "id" : 687691515167019008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/687691515167019008\/pu\/img\/lNWrxqngAzseuY13.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jA1MEbwcxg"
    } ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687691919065915392",
  "text" : "Hey everyone! Ready to answer your questions here at McKinley High School in Baton Rouge. Let's do this. #AskPOTUS https:\/\/t.co\/jA1MEbwcxg",
  "id" : 687691919065915392,
  "created_at" : "2016-01-14 17:45:04 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687650227558326272",
  "text" : "Looking forward to hearing your ideas about what we can accomplish this year &amp; beyond. I'll answer your questions on #AskPOTUS at 12:30p ET.",
  "id" : 687650227558326272,
  "created_at" : "2016-01-14 14:59:24 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687081708886355968",
  "text" : "I'm treating this last State of the Union just like my first - because I'm still just as hungry. I hope you tune in, because it's for you.",
  "id" : 687081708886355968,
  "created_at" : "2016-01-13 01:20:19 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/doBpaDeZXq",
      "expanded_url" : "https:\/\/twitter.com\/stationcdrkelly\/status\/687023415606165504",
      "display_url" : "twitter.com\/stationcdrkell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687046052822781952",
  "text" : "So proud of you, Scott. How long is the delay up there? See you when you get back!  https:\/\/t.co\/doBpaDeZXq",
  "id" : 687046052822781952,
  "created_at" : "2016-01-12 22:58:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/WullueHj28",
      "expanded_url" : "https:\/\/twitter.com\/denis44\/status\/684858419174617088",
      "display_url" : "twitter.com\/denis44\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684862266978742272",
  "text" : "About time, Denis! Welcome. Let me know if you need any pointers. https:\/\/t.co\/WullueHj28",
  "id" : 684862266978742272,
  "created_at" : "2016-01-06 22:21:03 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684157715837403136",
  "geo" : { },
  "id_str" : "684158987185614849",
  "in_reply_to_user_id" : 1536791610,
  "text" : "The gun lobby may be holding Congress hostage, but they can't hold America hostage. We can't accept this carnage in our communities.",
  "id" : 684158987185614849,
  "in_reply_to_status_id" : 684157715837403136,
  "created_at" : "2016-01-04 23:46:28 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684156422179786752",
  "geo" : { },
  "id_str" : "684157715837403136",
  "in_reply_to_user_id" : 1536791610,
  "text" : "What's often ignored in this debate is that a majority of gun owners agree with commonsense steps to save lives.",
  "id" : 684157715837403136,
  "in_reply_to_status_id" : 684156422179786752,
  "created_at" : "2016-01-04 23:41:25 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684155537433309184",
  "geo" : { },
  "id_str" : "684156422179786752",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We will keep guns out of the wrong hands, enforce our guns laws, and ensure those with serious mental illnesses get treatment.",
  "id" : 684156422179786752,
  "in_reply_to_status_id" : 684155537433309184,
  "created_at" : "2016-01-04 23:36:16 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/684155537433309184\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/vNqXEhaC9M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6b1fNU0AEdrgV.jpg",
      "id_str" : "684155536619655169",
      "id" : 684155536619655169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6b1fNU0AEdrgV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vNqXEhaC9M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684154637436370944",
  "geo" : { },
  "id_str" : "684155537433309184",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Tomorrow, I'm taking action to reduce gun violence and save lives - protecting the Second Amendment and our kids. https:\/\/t.co\/vNqXEhaC9M",
  "id" : 684155537433309184,
  "in_reply_to_status_id" : 684154637436370944,
  "created_at" : "2016-01-04 23:32:45 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684153926636015616",
  "geo" : { },
  "id_str" : "684154637436370944",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Guns now kill as many people as cars in almost half of the U.S. We can't stop every act of violence, but we can save lives if we act.",
  "id" : 684154637436370944,
  "in_reply_to_status_id" : 684153926636015616,
  "created_at" : "2016-01-04 23:29:11 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684153926636015616",
  "text" : "Each year, more than 30,000 American lives are cut short by guns - two-thirds coming from suicides. Too many Americans have lost loved ones.",
  "id" : 684153926636015616,
  "created_at" : "2016-01-04 23:26:21 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]
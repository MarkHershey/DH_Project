Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/lFZjSnn38x",
      "expanded_url" : "http:\/\/usat.ly\/2c79F6j",
      "display_url" : "usat.ly\/2c79F6j"
    } ]
  },
  "geo" : { },
  "id_str" : "770297035274584068",
  "text" : "Congrats to NASA and the scientists taking us a step closer to Mars. Now enjoy Hawaii and get a shave ice! https:\/\/t.co\/lFZjSnn38x",
  "id" : 770297035274584068,
  "created_at" : "2016-08-29 16:28:19 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770050438578184192",
  "text" : "Congratulations to Maine-Endwell, Little League World Series Champs and still undefeated! Proud of you and the sportsmanship you showed.",
  "id" : 770050438578184192,
  "created_at" : "2016-08-29 00:08:26 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769204867235667969",
  "text" : "Nearly 100 years ago, women broke down barriers to the ballot box, moving us closer to a more equal nation. Let's finish what they started.",
  "id" : 769204867235667969,
  "created_at" : "2016-08-26 16:08:26 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 35, 51 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/768871824885026817\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/1v3W2HLD6f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CquTLgLXYAApMAT.jpg",
      "id_str" : "768869987222249472",
      "id" : 768869987222249472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CquTLgLXYAApMAT.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1v3W2HLD6f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768871824885026817",
  "text" : "100 years and going strong. Thanks @NatlParkService for your service, so our kids enjoy our parks as much as we have https:\/\/t.co\/1v3W2HLD6f",
  "id" : 768871824885026817,
  "created_at" : "2016-08-25 18:05:02 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Manuel Santos",
      "screen_name" : "JuanManSantos",
      "indices" : [ 16, 30 ],
      "id_str" : "64839766",
      "id" : 64839766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/haXJaqgS9f",
      "expanded_url" : "https:\/\/twitter.com\/JuanManSantos\/status\/768614115019489281",
      "display_url" : "twitter.com\/JuanManSantos\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768833523729903618",
  "text" : "Felicitaciones, @JuanManSantos and Colombia. After decades of war, we stand with you in building a future of peace. https:\/\/t.co\/haXJaqgS9f",
  "id" : 768833523729903618,
  "created_at" : "2016-08-25 15:32:50 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simone Biles",
      "screen_name" : "Simone_Biles",
      "indices" : [ 124, 137 ],
      "id_str" : "173677727",
      "id" : 173677727
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767528566099701760",
  "text" : "Couldn't be prouder of #TeamUSA. Your determination and passion inspired so many of us. You carried that flag high tonight, @Simone_Biles!",
  "id" : 767528566099701760,
  "created_at" : "2016-08-22 01:07:24 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764961309767131136",
  "text" : "Final win for Phelps. World record for Ledecky. 3 #1 finishes for Biles. That's how #TeamUSA gets America to 1000 golds-way to make history.",
  "id" : 764961309767131136,
  "created_at" : "2016-08-14 23:06:03 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/mqh1YVrycj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
      "id_str" : "763743855917174784",
      "id" : 763743855917174784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mqh1YVrycj"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/mqh1YVrycj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
      "id_str" : "763743895695994881",
      "id" : 763743895695994881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mqh1YVrycj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763744742072913920",
  "text" : "Been waiting to drop this: summer playlist, the encore. What's everybody listening to? https:\/\/t.co\/mqh1YVrycj",
  "id" : 763744742072913920,
  "created_at" : "2016-08-11 14:31:50 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762030430954684416",
  "text" : "The struggle for the Voting Rights Act taught us that people who love this country can change it. Don't give away your power - go vote.",
  "id" : 762030430954684416,
  "created_at" : "2016-08-06 20:59:47 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamRefugees",
      "indices" : [ 24, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761703659411345408",
  "geo" : { },
  "id_str" : "761703867402686464",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Tonight, the first-ever #TeamRefugees will also stand before the world and prove that you can succeed no matter where you're from.",
  "id" : 761703867402686464,
  "in_reply_to_status_id" : 761703659411345408,
  "created_at" : "2016-08-05 23:22:08 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761703659411345408",
  "text" : "Ready to root on #TeamUSA! Our team's unity and diversity makes us so proud - and reminds the world why America sets the gold standard.",
  "id" : 761703659411345408,
  "created_at" : "2016-08-05 23:21:18 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761640808009302016",
  "text" : "Longest streak of total job growth on record, wages rising at fastest pace in 7 years. We've come a long way, America\u2014let's keep it going.",
  "id" : 761640808009302016,
  "created_at" : "2016-08-05 19:11:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]
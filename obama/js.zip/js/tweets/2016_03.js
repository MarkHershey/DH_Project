Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hal Rogers",
      "screen_name" : "RepHalRogers",
      "indices" : [ 30, 43 ],
      "id_str" : "550401754",
      "id" : 550401754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714844724050309121",
  "geo" : { },
  "id_str" : "714871062865903616",
  "in_reply_to_user_id" : 550401754,
  "text" : "Thank you for your leadership @RepHalRogers. This epidemic doesn't discriminate between red or blue, so it's up to all of us to do our part.",
  "id" : 714871062865903616,
  "in_reply_to_status_id" : 714844724050309121,
  "created_at" : "2016-03-29 17:45:17 +0000",
  "in_reply_to_screen_name" : "RepHalRogers",
  "in_reply_to_user_id_str" : "550401754",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hal Rogers",
      "screen_name" : "RepHalRogers",
      "indices" : [ 3, 16 ],
      "id_str" : "550401754",
      "id" : 550401754
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rx Drug Abuse Summit",
      "screen_name" : "RxSummit",
      "indices" : [ 64, 73 ],
      "id_str" : "425872825",
      "id" : 425872825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714870949594603520",
  "text" : "RT @RepHalRogers: Honored to have our Commander-in-Chief @POTUS @RxSummit to lead this critical discussion about the nation's drug abuse ep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 39, 45 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Rx Drug Abuse Summit",
        "screen_name" : "RxSummit",
        "indices" : [ 46, 55 ],
        "id_str" : "425872825",
        "id" : 425872825
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714844724050309121",
    "text" : "Honored to have our Commander-in-Chief @POTUS @RxSummit to lead this critical discussion about the nation's drug abuse epidemic.",
    "id" : 714844724050309121,
    "created_at" : "2016-03-29 16:00:38 +0000",
    "user" : {
      "name" : "Hal Rogers",
      "screen_name" : "RepHalRogers",
      "protected" : false,
      "id_str" : "550401754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2087954082\/Hal_twitter_pic_normal.jpg",
      "id" : 550401754,
      "verified" : true
    }
  },
  "id" : 714870949594603520,
  "created_at" : "2016-03-29 17:44:50 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/714084384010272768\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/fNvcihSmYB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cejv8yXW4AAdvdJ.jpg",
      "id_str" : "714084368529154048",
      "id" : 714084368529154048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cejv8yXW4AAdvdJ.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fNvcihSmYB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714084384010272768",
  "text" : "From my family to yours, Happy Easter, and we wish everyone celebrating a blessed and joyful day. https:\/\/t.co\/fNvcihSmYB",
  "id" : 714084384010272768,
  "created_at" : "2016-03-27 13:39:18 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711649199243177984",
  "text" : "\u00BFQue bol\u00E1 Cuba? Just touched down here, looking forward to meeting and hearing directly from the Cuban people.",
  "id" : 711649199243177984,
  "created_at" : "2016-03-20 20:22:45 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/dFU57cuxo8",
      "expanded_url" : "https:\/\/twitter.com\/WorkSteven\/status\/710302819278925824",
      "display_url" : "twitter.com\/WorkSteven\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710599731827834880",
  "text" : "A great example of how tech can make our democracy stronger. Thanks for answering the call to serve. https:\/\/t.co\/dFU57cuxo8",
  "id" : 710599731827834880,
  "created_at" : "2016-03-17 22:52:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUSnominee",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ACujysyyDJ",
      "expanded_url" : "http:\/\/go.wh.gov\/MerrickGarland",
      "display_url" : "go.wh.gov\/MerrickGarland"
    } ]
  },
  "geo" : { },
  "id_str" : "710141347051786244",
  "text" : "RT @SCOTUSnom: Meet Chief Judge Merrick Garland, the President's nominee to the Supreme Court. #SCOTUSnominee https:\/\/t.co\/ACujysyyDJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUSnominee",
        "indices" : [ 80, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/ACujysyyDJ",
        "expanded_url" : "http:\/\/go.wh.gov\/MerrickGarland",
        "display_url" : "go.wh.gov\/MerrickGarland"
      } ]
    },
    "geo" : { },
    "id_str" : "710127524014104576",
    "text" : "Meet Chief Judge Merrick Garland, the President's nominee to the Supreme Court. #SCOTUSnominee https:\/\/t.co\/ACujysyyDJ",
    "id" : 710127524014104576,
    "created_at" : "2016-03-16 15:36:09 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 710141347051786244,
  "created_at" : "2016-03-16 16:31:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710141204755783681",
  "text" : "Proud to nominate Judge Merrick Garland to the Supreme Court. I ask Senators to meet their constitutional duty and give him a fair hearing.",
  "id" : 710141204755783681,
  "created_at" : "2016-03-16 16:30:31 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708346933933416449",
  "geo" : { },
  "id_str" : "708348813858054145",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Looking forward to discussing more ways we can modernize government so it's as smart and dynamic as America itself. See you soon, Austin.",
  "id" : 708348813858054145,
  "in_reply_to_status_id" : 708346933933416449,
  "created_at" : "2016-03-11 17:48:12 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/jPEHLkNxfk",
      "expanded_url" : "http:\/\/1.usa.gov\/1RTe2O8",
      "display_url" : "1.usa.gov\/1RTe2O8"
    } ]
  },
  "in_reply_to_status_id_str" : "708346091578593280",
  "geo" : { },
  "id_str" : "708346933933416449",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Seniors can now apply for Social Security benefits online: https:\/\/t.co\/jPEHLkNxfk",
  "id" : 708346933933416449,
  "in_reply_to_status_id" : 708346091578593280,
  "created_at" : "2016-03-11 17:40:44 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/708346091578593280\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fxvdOCFeET",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdSNBEAW8AARFeS.jpg",
      "id_str" : "708346090798641152",
      "id" : 708346090798641152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdSNBEAW8AARFeS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fxvdOCFeET"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708345011037798400",
  "geo" : { },
  "id_str" : "708346091578593280",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Nearly 1 in 3 American families struggle to afford diapers. We're working with the private sector to help fix this. https:\/\/t.co\/fxvdOCFeET",
  "id" : 708346091578593280,
  "in_reply_to_status_id" : 708345011037798400,
  "created_at" : "2016-03-11 17:37:23 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708344230729555970",
  "geo" : { },
  "id_str" : "708345011037798400",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Immigrants can now apply online to renew their green cards faster, and prep for the citizenship civics test online.",
  "id" : 708345011037798400,
  "in_reply_to_status_id" : 708344230729555970,
  "created_at" : "2016-03-11 17:33:05 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/WDD1UrSXIR",
      "expanded_url" : "http:\/\/fafsa.gov",
      "display_url" : "fafsa.gov"
    } ]
  },
  "in_reply_to_status_id_str" : "708343852470435840",
  "geo" : { },
  "id_str" : "708344230729555970",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We've cut the time it takes students to apply for financial aid by two-thirds thanks to a simplified FAFSA form: https:\/\/t.co\/WDD1UrSXIR",
  "id" : 708344230729555970,
  "in_reply_to_status_id" : 708343852470435840,
  "created_at" : "2016-03-11 17:29:59 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSW",
      "indices" : [ 3, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708343852470435840",
  "text" : "At #SXSW, I'll make the case that tech and innovation can make government work better for everyone. Here's how it's working better already:",
  "id" : 708343852470435840,
  "created_at" : "2016-03-11 17:28:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InternationalWomensDay",
      "indices" : [ 6, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707323697493704704",
  "text" : "Happy #InternationalWomensDay! When women are free to pursue their dreams, nations are more safe, more secure, and more prosperous.",
  "id" : 707323697493704704,
  "created_at" : "2016-03-08 21:54:45 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 23, 39 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705090664086773764",
  "text" : "Welcome back to Earth, @StationCDRKelly! Your year in space is vital to the future of American space travel. Hope gravity isn't a drag!",
  "id" : 705090664086773764,
  "created_at" : "2016-03-02 18:01:28 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/S4DhVYa4Ef",
      "expanded_url" : "https:\/\/twitter.com\/mlb\/status\/704825692890923008",
      "display_url" : "twitter.com\/mlb\/status\/704\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704827179167846400",
  "text" : "Play ball! https:\/\/t.co\/S4DhVYa4Ef",
  "id" : 704827179167846400,
  "created_at" : "2016-03-02 00:34:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]
Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723568187447500800",
  "text" : "Today, the US joined some 170 nations to sign the Paris Agreement - an historic step this Earth Day to protect the one planet we've got.",
  "id" : 723568187447500800,
  "created_at" : "2016-04-22 17:44:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/55hmcsCHbJ",
      "expanded_url" : "http:\/\/cbsloc.al\/1S6LCSs",
      "display_url" : "cbsloc.al\/1S6LCSs"
    } ]
  },
  "geo" : { },
  "id_str" : "722217866330636288",
  "text" : "Thank you, Adrianne, for being Boston Strong. Terror and bombs can't beat us. We carry on. We finish the race! https:\/\/t.co\/55hmcsCHbJ",
  "id" : 722217866330636288,
  "created_at" : "2016-04-19 00:18:52 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 16, 25 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720476914243280896",
  "text" : "Congrats to the @Warriors, a great group of guys on and off the court. If somebody had to break the Bulls' record, I'm glad it's them.",
  "id" : 720476914243280896,
  "created_at" : "2016-04-14 05:00:56 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 26, 35 ],
      "id_str" : "26270913",
      "id" : 26270913
    }, {
      "name" : "Kobe Bryant",
      "screen_name" : "kobebryant",
      "indices" : [ 80, 91 ],
      "id_str" : "1059194370",
      "id" : 1059194370
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/720416675196223488\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hvno2ZO5b0",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf9u8jmVIAEiO_e.jpg",
      "id_str" : "720416452029784065",
      "id" : 720416452029784065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf9u8jmVIAEiO_e.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hvno2ZO5b0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720416675196223488",
  "text" : "Big night of basketball - @Warriors chasing 73 and a farewell for an\nall-timer, @KobeBryant. NBA fans feeling like: https:\/\/t.co\/hvno2ZO5b0",
  "id" : 720416675196223488,
  "created_at" : "2016-04-14 01:01:34 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719899559988740096",
  "text" : "Proud to designate the Belmont-Paul national monument for women's equality. Let's keep up their fight with #EqualPay for women today.",
  "id" : 719899559988740096,
  "created_at" : "2016-04-12 14:46:44 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718579793919238144",
  "text" : "Congrats SpaceX on landing a rocket at sea. It's because of innovators like you &amp; NASA that America continues to lead in space exploration.",
  "id" : 718579793919238144,
  "created_at" : "2016-04-08 23:22:28 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717131662170173440",
  "text" : "RT @repjohnlewis: 48 yrs ago today, my friend, my brother, Dr. Martin Luther King, Jr. was shot and killed in Memphis, TN. The light of his\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717004180829954048",
    "text" : "48 yrs ago today, my friend, my brother, Dr. Martin Luther King, Jr. was shot and killed in Memphis, TN. The light of his life still shines.",
    "id" : 717004180829954048,
    "created_at" : "2016-04-04 15:01:32 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 717131662170173440,
  "created_at" : "2016-04-04 23:28:06 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 96, 107 ],
      "id_str" : "232268199",
      "id" : 232268199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717026378739290112",
  "text" : "Nobody should have to choose between losing a paycheck &amp; caring for their family. I applaud @NYGovCuomo for taking a big step on paid leave.",
  "id" : 717026378739290112,
  "created_at" : "2016-04-04 16:29:45 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]
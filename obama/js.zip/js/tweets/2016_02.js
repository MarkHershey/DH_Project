Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/RakSNxe7rk",
      "expanded_url" : "http:\/\/huff.to\/21u24PG",
      "display_url" : "huff.to\/21u24PG"
    } ]
  },
  "geo" : { },
  "id_str" : "703359876483977217",
  "text" : "Isiah, I'm so proud of you. Your kindness and willingness to help others is why I'm so hopeful for our future. https:\/\/t.co\/RakSNxe7rk",
  "id" : 703359876483977217,
  "created_at" : "2016-02-26 23:23:57 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/701871557002407936\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jVdeE4Qktw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb2MdLUUUAA3FcI.jpg",
      "id_str" : "701871549821767680",
      "id" : 701871549821767680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb2MdLUUUAA3FcI.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/jVdeE4Qktw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701871557002407936",
  "text" : "We've made big strides in the fight against Malaria - saving millions of lives. That's American leadership at work. https:\/\/t.co\/jVdeE4Qktw",
  "id" : 701871557002407936,
  "created_at" : "2016-02-22 20:49:53 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/a0KcsmpF39",
      "expanded_url" : "http:\/\/go.wh.gov\/4b4M4z",
      "display_url" : "go.wh.gov\/4b4M4z"
    } ]
  },
  "in_reply_to_status_id_str" : "700320240022921216",
  "geo" : { },
  "id_str" : "700320856858189824",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Here's how we're looking at the road ahead: https:\/\/t.co\/a0KcsmpF39",
  "id" : 700320856858189824,
  "in_reply_to_status_id" : 700320240022921216,
  "created_at" : "2016-02-18 14:07:58 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700319754054074368",
  "geo" : { },
  "id_str" : "700320240022921216",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Next month, I'll travel to Cuba to advance our progress and efforts that can improve the lives of the Cuban people.",
  "id" : 700320240022921216,
  "in_reply_to_status_id" : 700319754054074368,
  "created_at" : "2016-02-18 14:05:31 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700319236451741697",
  "geo" : { },
  "id_str" : "700319754054074368",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We still have differences with the Cuban government that I will raise directly. America will always stand for human rights around the world.",
  "id" : 700319754054074368,
  "in_reply_to_status_id" : 700319236451741697,
  "created_at" : "2016-02-18 14:03:35 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700318872147066880",
  "geo" : { },
  "id_str" : "700319236451741697",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Our flag flies over our Embassy in Havana once again. More Americans are traveling to Cuba than at any time in the last 50 years.",
  "id" : 700319236451741697,
  "in_reply_to_status_id" : 700318872147066880,
  "created_at" : "2016-02-18 14:01:31 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700318872147066880",
  "text" : "14 months ago, I announced that we would begin normalizing relations with Cuba - and we've already made significant progress.",
  "id" : 700318872147066880,
  "created_at" : "2016-02-18 14:00:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/698574908247425024\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/8OR9MrupyG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbHWKkdXIAIfmgu.jpg",
      "id_str" : "698574894293000194",
      "id" : 698574894293000194,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbHWKkdXIAIfmgu.jpg",
      "sizes" : [ {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8OR9MrupyG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698574908247425024",
  "text" : "Got a view yesterday of the lands we protected in CA. We owe it to our kids to preserve America's natural beauty. https:\/\/t.co\/8OR9MrupyG",
  "id" : 698574908247425024,
  "created_at" : "2016-02-13 18:30:11 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 32, 36 ],
      "id_str" : "16245822",
      "id" : 16245822
    }, {
      "name" : "LIGO",
      "screen_name" : "LIGO",
      "indices" : [ 41, 46 ],
      "id_str" : "15000857",
      "id" : 15000857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697928913457188864",
  "text" : "Einstein was right! Congrats to @NSF and @LIGO on detecting gravitational waves - a huge breakthrough in how we understand the universe.",
  "id" : 697928913457188864,
  "created_at" : "2016-02-11 23:43:14 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/hFaAgxVdEE",
      "expanded_url" : "http:\/\/wapo.st\/1RpdCk9",
      "display_url" : "wapo.st\/1RpdCk9"
    } ]
  },
  "geo" : { },
  "id_str" : "697824490344968192",
  "text" : "Way to ace your AP Calc test, Landon! You should come drop some knowledge at the White House Science Fair: https:\/\/t.co\/hFaAgxVdEE",
  "id" : 697824490344968192,
  "created_at" : "2016-02-11 16:48:18 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 91, 99 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697185842209689601",
  "text" : "Just got off the phone with Coach Kubiak. Congrats to Peyton, Von Miller, and that monster @Broncos defense - see you at the White House!",
  "id" : 697185842209689601,
  "created_at" : "2016-02-09 22:30:32 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695381352988848128",
  "text" : "Just got great news - nearly 13 million Americans signed up this round for private health insurance thanks to the Affordable Care Act.",
  "id" : 695381352988848128,
  "created_at" : "2016-02-04 23:00:08 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]
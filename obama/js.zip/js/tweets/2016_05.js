Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737267478661730304",
  "text" : "This Memorial Day, I hope you'll join me in acts of remembrance. The debt we owe our fallen heroes is one we can never truly repay.",
  "id" : 737267478661730304,
  "created_at" : "2016-05-30 13:00:39 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/732266263528001537\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OufzQ70ovH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CimIBfWXIAALZ2o.jpg",
      "id_str" : "732265973600952320",
      "id" : 732265973600952320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimIBfWXIAALZ2o.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OufzQ70ovH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732266263528001537",
  "text" : "Today, I join all Americans in honoring 13 officers who went beyond the call of duty to save the lives of strangers. https:\/\/t.co\/OufzQ70ovH",
  "id" : 732266263528001537,
  "created_at" : "2016-05-16 17:47:36 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PunahouSchool\/status\/593489304770498561\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fz2ij8daBg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDx_YBKWYAA7d3o.png",
      "id_str" : "593489301511495680",
      "id" : 593489301511495680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDx_YBKWYAA7d3o.png",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1108,
        "resize" : "fit",
        "w" : 1738
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fz2ij8daBg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727561463993270272",
  "text" : "To my 5th grade teacher Ms. Mabel Hefty and the educators who inspire our young people every single day: Thank you. https:\/\/t.co\/fz2ij8daBg",
  "id" : 727561463993270272,
  "created_at" : "2016-05-03 18:12:25 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]